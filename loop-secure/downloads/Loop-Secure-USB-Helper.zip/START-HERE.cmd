@echo off
call "%~dp0Enroll-Windows.cmd"

@echo off
call "%~dp0Update-Windows.cmd"
